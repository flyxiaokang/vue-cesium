module.exports = {
    lintOnSave: false
}